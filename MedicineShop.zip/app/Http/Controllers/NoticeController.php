<?php

namespace App\Http\Controllers;

use App\Notice;
use Illuminate\Http\Request;

class NoticeController extends Controller
{
    public function index()
    {
       $noticeTop = Notice::all()->first();
       $notice =  Notice::offset(1)
               ->limit(5)
               ->get();;
        return view('pages.notice',compact('notice','noticeTop'));
    }
}

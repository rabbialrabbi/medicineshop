<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MR extends Model
{
    public $guarded = [];
}

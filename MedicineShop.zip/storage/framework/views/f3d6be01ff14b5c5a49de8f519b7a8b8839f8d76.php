<?php $__env->startSection('notice-active','active'); ?>

<?php $__env->startSection('body'); ?>
    <div class="container about-header">


        <div class="row">
            <div class="col-sm-12 col-md-9">
                <h1 class="text-center">Notice</h1>
<!--                <hr class="about-uline">-->
                <p class="text-center pt-5"><?php echo e($noticeTop->notice); ?></p>
            </div>
            <div class="col-sm-12 col-md-3 notice-history notice-history_text">
                <div class="card">
                    <div class="card-header notice-history_text-header ">
                        <h4 class="card-title text-center">HISTORY</h4>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body notice-log">
                        <?php $__currentLoopData = $notice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div><?php echo e($n->created_at); ?></div>
                            <p class="pt-1"><?php echo e(substr($n->notice,0,100)); ?> </p>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache\htdocs\Project\Boyshaki\MedicineShop\resources\views/pages/notice.blade.php ENDPATH**/ ?>
<aside class="control-sidebar control-sidebar-<?php echo e(config('adminlte.right_sidebar_theme')); ?>">
    <?php echo $__env->yieldContent('right-sidebar'); ?>
</aside>
<?php /**PATH D:\Apache\htdocs\Project\Boyshaki\MedicineShop\vendor\jeroennoten\laravel-adminlte\src/../resources/views/partials/sidebar/right-sidebar.blade.php ENDPATH**/ ?>
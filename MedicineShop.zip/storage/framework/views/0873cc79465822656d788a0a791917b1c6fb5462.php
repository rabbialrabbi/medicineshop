

<?php $__env->startSection('title','MR Show'); ?>

<?php $__env->startSection('content_header'); ?>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Invoice</h1>
                </div>
                
            </div>
        </div><!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content_body'); ?>

    <invoice-component :order="<?php echo e(json_encode($order)); ?>"></invoice-component>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
        <script src="/js/app.js"></script>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache\htdocs\Project\Boyshaki\MedicineShop\resources\views/pages/show/showOrderElement.blade.php ENDPATH**/ ?>
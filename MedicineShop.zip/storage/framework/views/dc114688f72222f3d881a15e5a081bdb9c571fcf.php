<?php $__env->startSection('title',''); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Hi It is Header</h1>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache\htdocs\Project\Boyshaki\MedicineShop\resources\views/test.blade.php ENDPATH**/ ?>
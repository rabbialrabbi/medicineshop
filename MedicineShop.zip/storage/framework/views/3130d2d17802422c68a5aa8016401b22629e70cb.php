<?php $__env->startSection('title','Item Show'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="pt-3" style="text-align: center"><?php echo e($item->name); ?></h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content_body'); ?>
    <div class="container mr-element">
        <div class="row">
            <div class="col-sm-12 col-md-4 pt-5">
                <img class="mr-element_img" src="/storage/item/<?php echo e($item->image); ?>" alt="<?php echo e($item->name); ?>" height="300px" width="300px">
            </div>
            <div class="col-sm-12 col-md-8 pt-5">
                <form role="form"  >
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-6 col-md-8">
                                <div class="form-group">
                                    <label for="exampleInputName">Item Name</label>
                                    <input type="text" name="name" class="form-control" value="<?php echo e($item->name); ?>" id="exampleInputName" placeholder="<?php echo e($item->name); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <div class="form-group">
                                    <label for="exampleInputCode">Item Code</label>
                                    <input type="text" name="code" class="form-control" value="<?php echo e($item->code); ?>" id="exampleInputCode" placeholder="<?php echo e($item->code); ?>" disabled>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-6 col-md-3">
                                <div class="form-group">
                                    <label for="exampleInputDosage">Dosage</label>
                                    <input type="text" name="dosage" class="form-control" value="<?php echo e($item->dosage); ?>" id="exampleInputDosage" placeholder="<?php echo e($item->dosage); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-3">
                                <div class="form-group">
                                    <label for="exampleInputSize">Size</label>
                                    <input type="text" name="size" class="form-control" value="<?php echo e($item->size); ?>" id="exampleInputSize" placeholder="<?php echo e($item->size); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputPrice">Price</label>
                                    <input type="text" name="price" class="form-control" value="<?php echo e($item->price); ?>" id="exampleInputPrice" placeholder="<?php echo e($item->price); ?>" disabled>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>Item Type</label>
                                    <input type="text"  class="form-control" value="<?php echo e($item->itemType->name); ?>" id="exampleInputPrice" placeholder="<?php echo e($item->itemType->name); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>Generic Name</label>
                                    <input type="text" name="price" class="form-control" value="<?php echo e($item->generic->name); ?>" id="exampleInputPrice" placeholder="<?php echo e($item->generic->name); ?>" disabled>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group ">
                                    <label>Brand Name</label>
                                    <input type="text" name="price" class="form-control" value="<?php echo e($item->brand->name); ?>" id="exampleInputPrice" placeholder="<?php echo e($item->brand->name); ?>" disabled>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea class="form-control" rows="3" value="<?php echo e($item->description); ?>" placeholder="<?php echo e($item->description); ?>" name="description" disabled></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="row mt-5 text-center">
            <div class="col card-footer">
                <a class="btn btn-warning px-4" href="<?php echo e(route('item.index')); ?>">
                    Back
                </a>
            </div>
            <div class="col card-footer">
                <a class="btn btn-success px-4" href="<?php echo e(route('item.edit',['item'=>$item->id])); ?>">
                    Edit
                </a>
            </div>
            <div class="col card-footer">
                <a class="btn btn-danger" href="<?php echo e(route('item.destroy',['item'=>$item->id])); ?>"
                   onclick="event.preventDefault();
                                                     document.getElementById('item-delete').submit();">
                    Delete
                </a>
                <form id="item-delete" action="<?php echo e(route('item.destroy',['item'=>$item->id])); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache\htdocs\Project\Boyshaki\MedicineShop\resources\views/pages/show/showItemElement.blade.php ENDPATH**/ ?>
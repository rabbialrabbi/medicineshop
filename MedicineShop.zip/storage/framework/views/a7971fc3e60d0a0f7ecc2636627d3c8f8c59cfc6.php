<?php $__env->startSection('title','Home'); ?>

<?php echo $__env->yieldContent('nav-active'); ?>

<?php $__env->startSection('content'); ?>

    <div class="ht-link" >
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-6 ht-link_button">
                    <div class="row">
                        <div ><a href="#">About Us</a><span>|</span></div>
                        <div ><a href="#">Product Price List</a><span>|</span></div>
                        <div ><a href="#">Contact Us</a><span>|</span></div>
                        <div ><a href="#">Extra</a><span>|</span></div>
                    </div>
                </div>
                <div class="col-6 switch-button d-none d-md-block ">
                    <span class="switch-text">English</span>
                    <label class="switch">
                        <?php if(session()->get('locale') == 'bd'): ?>
                        <input type="checkbox" onclick="window.location.href='<?php echo e(route("home.view",["locale"=>"en"])); ?>'" checked>
                            <?php else: ?>
                            <input type="checkbox" onclick="window.location.href='<?php echo e(route("home.view",["locale"=>"bd"])); ?>'" >
                        <?php endif; ?>
                        <div>
                            <span></span>
                        </div>
                    </label>
                    <span class="switch-text">বাংলা</span>
                </div>
            </div>

        </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-light header-nav">
        <a class="d-block d-lg-none nav-logo" href="#">MedicineShop</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="container">
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $__env->yieldContent('home-active'); ?>" href="<?php echo e(route('home.view')); ?>"><?php echo e(__('front.home')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $__env->yieldContent('about-active'); ?>" href="<?php echo e(route('home.about')); ?>"><?php echo e(__('front.about_us')); ?></a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?php echo $__env->yieldContent('product-active'); ?>" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo e(__('front.product')); ?>

                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <?php $__currentLoopData = $itemType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="dropdown-item" href="<?php echo e(route('front.filter',['itemType'=>$i->id])); ?>"><?php echo e($i->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <a class="dropdown-item" href="#">Another action</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-center" href="#">All</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $__env->yieldContent('mr-active'); ?>" href="<?php echo e(route('home.mr')); ?>"><?php echo e(__('front.mr_list')); ?></a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?php echo $__env->yieldContent('message-active'); ?>" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo e(__('front.message')); ?>

                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('message.chairman')); ?>">Chairman message</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('message.md')); ?>">MD message</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('message.ed')); ?>">ED message</a>

                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $__env->yieldContent('notice-active'); ?>" href="<?php echo e(route('notice.index')); ?>"><?php echo e(__('front.notice')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $__env->yieldContent('contact-active'); ?>" href="<?php echo e(route('home.contact')); ?>"><?php echo e(__('front.contact')); ?></a>
                    </li>
                    <?php if(Auth()->check()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <?php echo e(__('front.log_out')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                        <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('front.log_in')); ?></a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('promo'); ?>

    <?php echo $__env->yieldContent('body'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache\htdocs\Project\Boyshaki\MedicineShop\resources\views/layouts/frontLayout.blade.php ENDPATH**/ ?>

<?php $__env->startSection('adminlte_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/css/adminlte/custom.css')); ?>">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_top_nav_left'); ?>
    <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(route('home.view')); ?>" class="nav-link">Home</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_top_nav_right'); ?>

    <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
            <i class="far fa-comments"></i>
            <span class="badge badge-danger navbar-badge"><?php echo e($users->count()); ?></span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">

            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div href="#" class="dropdown-item">

                    <!-- Message Start -->
                    <div class="media">
                        <img src="<?php echo e(asset('images/user.png')); ?>" alt="User Avatar" class="img-size-50 mr-3 img-circle">
                        <div class="media-body">
                            <h3 class="dropdown-item-title">
                                <?php echo e($u->name); ?>

                            </h3>
                            <p class="text-sm">Please Accept my ...</p>
                            <p class="text-sm text-muted">
                                <i class="fas fa-user-plus nav-user_request" onclick="event.preventDefault();document.getElementById('include_user<?php echo e($u->id); ?>').submit();"></i>
                                <i class="fas fa-trash-alt nav-user_request" onclick="event.preventDefault();document.getElementById('delete_user<?php echo e($u->id); ?>').submit();"></i>
                            </p>
                            <form id="include_user<?php echo e($u->id); ?>" action="<?php echo e(route('mr.create')); ?>" method="GET" style="display: none;">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="user_id" value="<?php echo e($u->id); ?>">
                                <input type="hidden" name="name" value="<?php echo e($u->name); ?>">
                                <input type="hidden" name="email" value="<?php echo e($u->email); ?>">
                            </form>
                            <form id="delete_user<?php echo e($u->id); ?>" action="<?php echo e(route('admin.delete',['user'=>$u->id])); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                        </div>
                    </div>
                    <!-- Message End -->
                </div>
                <div class="dropdown-divider"></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="dropdown-divider"></div>
            <a href="#" class="dropdown-item dropdown-footer">See All Messages</a>
        </div>
    </li>

    <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
            <i class="far fa-bell"></i>
            <span class="badge badge-warning navbar-badge"><?php echo e($pending_order->count()+$pending_message->count()); ?></span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
            <span class="dropdown-item dropdown-header"><?php echo e($pending_order->count()+$pending_message->count()); ?> Notifications</span>
            <div class="dropdown-divider"></div>
            <a href="#" class="dropdown-item">
                <i class="fas fa-file mr-2"></i><?php echo e($pending_order->count()); ?> Pending Order
                <span class="float-right text-muted text-sm"></span>
            </a>
            <div class="dropdown-divider"></div>
            <a href="#" class="dropdown-item">
                <i class="fas fa-envelope mr-2"></i> <?php echo e($pending_message->count()); ?> new messages
                <span class="float-right text-muted text-sm"></span>
            </a>







        </div>
    </li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="app">
        <?php echo $__env->yieldContent('content_body'); ?>
    </div>

    <?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache\htdocs\Project\Boyshaki\MedicineShop\resources\views/layouts/adminlte.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title','MR List'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 style="text-align: center">MR List</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class=" card card-warning card-outline">
        <div class="card-header">
            <h3 class="card-title">MR List</h3>
            <div class="card-tools">
                <form id="indexSearch" action="<?php echo e(route('mr.index')); ?>" method="get">
                <div class="input-group input-group-sm">
                    <input type="text" name="key" class="form-control" placeholder="Search MR">
                    <div class="input-group-append" onclick="event.preventDefault(); document.getElementById('indexSearch').submit();">
                        <div class="btn btn-primary">
                            <i class="fas fa-search" ></i>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>

        <div class="table-responsive mailbox-messages">
            <table class="table table-hover table-striped">
                <thead>
                <tr>
                    <th></th>
                    <th>Name</th>
                    <th>Code</th>
                    <th>Address</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>Fax</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr onclick="window.location='<?php echo e(route('mr.show',['mr'=>$g->id])); ?>'">
                        <td><img src="/storage/mrlist/<?php echo e($g->image); ?>" alt="<?php echo e($g->name); ?>" width="80px" height="80px"></td>
                        <td style="position: relative"> <div style="position: absolute;top: 50%;transform: translateY(-50%)"><?php echo e($g->name); ?></div></td>
                        <td style="position: relative"> <div style="position: absolute;top: 50%;transform: translateY(-50%)"><?php echo e($g->code); ?></div></td>
                        <td style="position: relative"> <div style="position: absolute;top: 50%;transform: translateY(-50%)"><?php echo e($g->address1); ?></div></td>
                        <td style="position: relative"> <div style="position: absolute;top: 50%;transform: translateY(-50%)"><?php echo e($g->contact1); ?></div></td>
                        <td style="position: relative"> <div style="position: absolute;top: 50%;transform: translateY(-50%)"><?php echo e($g->email1); ?></div></td>
                        <td style="position: relative"> <div style="position: absolute;top: 50%;transform: translateY(-50%)"><?php echo e($g->fax); ?></div></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache\htdocs\Project\Boyshaki\MedicineShop\resources\views/pages/show/showMRList.blade.php ENDPATH**/ ?>
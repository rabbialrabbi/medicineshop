

<?php $__env->startSection('title','MR List'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 style="text-align: center">MR List</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class=" card card-warning card-outline">
        <div class="card-header">
            <h3 class="card-title">MR List</h3>












        </div>

        <div class="table-responsive mailbox-messages">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th></th>
                    <th>Name</th>
                    <th>Code</th>
                    <th>Address</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="height: 50px" onclick="window.location='<?php echo e(route('mr.show',['mr'=>$g->id])); ?>'">
                        <td></td>
                        <td style="position: relative"> <div style="position: absolute;top: 50%;transform: translateY(-50%)"><?php echo e($g->name); ?></div></td>
                        <td style="position: relative"> <div style="position: absolute;top: 50%;transform: translateY(-50%)"><?php echo e($g->email); ?></div></td>
                        <td style="position: relative"> <div style="position: absolute;top: 50%;transform: translateY(-50%)"><?php echo e($g->message); ?></div></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache\htdocs\Project\Boyshaki\MedicineShop\resources\views/pages/show/showMessageList.blade.php ENDPATH**/ ?>
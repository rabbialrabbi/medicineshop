<?php $title = 'brand'?>


<?php $__env->startSection('title',ucfirst($title)); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 style="text-align: center"><?php echo e(ucfirst($title)); ?> Input Form</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container pt-5">
        <div class="card card-warning">
            <div class="card-header">
            </div>
            <form role="form" action="<?php echo e(route($title.'.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="form-group">
                        <label for="exampleInputEmail1"><?php echo e(ucfirst($title)); ?> Name</label>
                        <input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="<?php echo e('Enter '.ucfirst($title).' Name'); ?>">
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-warning">ADD</button>
                </div>
            </form>
        </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger mt-4" role="alert">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul>
                        <li><?php echo e($error); ?></li>
                    </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="container">
        <h4 style="text-align: center; padding: 30px 0 10px 0"><?php echo e(ucfirst($title)); ?> List</h4>
        <div class=" card card-warning card-outline ">
            <div class="card-header">
            <!--                <h3 class="card-title"><?php echo e($title); ?> List</h3>-->

                <div class="card-tools pr-5">
                    <a href="<?php echo e(route('brand.pdf')); ?>">View</a>
                </div>
            </div>

            <div class="table-responsive mailbox-messages">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th><?php echo e(ucfirst($title)); ?> Name</th>
                        <th>Status</th>
                        <th class="text-center">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                            </td>
                            <td class="mailbox-star"></td>
                            <td class="mailbox-name"></td>
                            <td id="table-show_name" class="mailbox-date">
                                <div id="table-show_name-data<?php echo e($g->id); ?>"><?php echo e($g->name); ?></div>
                                <form id="table-show_name-form<?php echo e($g->id); ?>" action="<?php echo e(route($title.'.update',[$title=>$g->id])); ?>" method="post" style="display: none">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <div class="input-group input-group-sm">
                                        <input type="text" name="name" class="form-control" value="<?php echo e($g->name); ?>" placeholder="<?php echo e($g->name); ?>">
                                        <div class="input-group-append" onclick="event.preventDefault(); document.getElementById('table-show_name-form<?php echo e($g->id); ?>').submit();">
                                            <div class="btn btn-primary">
                                                <i class="fas fa-plus" ></i>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </td>
                            <td class="mailbox-attachment">
                                <a class="" style="cursor: pointer" onclick="event.preventDefault(); document.getElementById('status-<?php echo e($g->id); ?>').submit();">
                                    <?php if($g->status == 'Inactive'): ?>
                                        <span class="badge-btn" style="background-color: lightgrey" ><?php echo e($g->status); ?></span>
                                    <?php else: ?>
                                        <span class="badge-btn bg-success px-3" ><?php echo e($g->status); ?></span>
                                    <?php endif; ?>
                                </a>
                                <form id="status-<?php echo e($g->id); ?>" action="<?php echo e(route($title.'.update',[$title=>$g->id])); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="Inactive">
                                </form>

                            </td>
                            <td class="mailbox-date text-center table-action">
                                <a class="" onclick="event.preventDefault(); document.getElementById('delete-item<?php echo e($g->id); ?>').submit();">
                                    <i class="fa fa-times table-action_delete" aria-hidden="true" ></i>
                                </a>
                                <form id="delete-item<?php echo e($g->id); ?>" action="<?php echo e(route($title.'.destroy',[$title=>$g->id])); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                </form>
                                <a class="pl-3">
                                    <i id="table-action_edit<?php echo e($g->id); ?>" class="fas fa-edit table-action_edit" key="<?php echo e($g->id); ?>"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('adminlte_js'); ?>
    
    <script>

        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        $('#table-action_edit<?php echo e($i->id); ?>').click(function () {
            $('#table-show_name-data<?php echo e($i->id); ?>').toggle()
            $('#table-show_name-form<?php echo e($i->id); ?>').toggle()
        })
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache\htdocs\Project\Boyshaki\MedicineShop\resources\views/pages/add/showBrandForm.blade.php ENDPATH**/ ?>
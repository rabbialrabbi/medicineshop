<?php $__env->startSection('title','MR Edit'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="pt-3" style="text-align: center"><?php echo e($mr->name); ?></h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content_body'); ?>
    <div class="container mr-element">
        <div class="row">
            <div class="col-sm-12 col-md-4 pt-5">
                <img class="mr-element_img" src="/storage/mrlist/<?php echo e($mr->image); ?>" alt="<?php echo e($mr->name); ?>" height="300px" width="300px">
            </div>
            <div class="col-sm-12 col-md-8 pt-5">
                <form id="mr-update" role="form" action="<?php echo e(route('mr.update',['mr'=>$mr->id])); ?>" method="post"enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="card-body">
                        <div class="row">

                            <!--Input Id From user table-->
                            <input type="hidden" name="user_id" class="form-control" value="<?php echo e($mr->user_id); ?>">

                            <div class="col-sm-6 col-md-8">
                                <div class="form-group">
                                    <label for="exampleInputName">MR Name</label>
                                    <input type="text" name="name" class="form-control" id="exampleInputName" value="<?php echo e($mr->name); ?>" placeholder="<?php echo e($mr->name); ?>">
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <div class="form-group">
                                    <label for="exampleInputCode">MR Code</label>
                                    <input type="text" name="code" class="form-control" id="exampleInputCode" value="<?php echo e($mr->code); ?>" placeholder="<?php echo e($mr->code); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-6 col-md-6">
                                <div id="address" class="form-group">
                                    <label for="exampleInputEmail1">Address</label>
                                    <div class="row" >
                                        <div class="col-sm-10">
                                            <input type="text" name="address1" class="form-control" id="exampleInputEmail1" value="<?php echo e($mr->address1); ?>" placeholder="<?php echo e($mr->address1); ?>">
                                        </div>
                                        <div class="col-sm-1 align-self-center text-center">
                                            <i id="addition_address" class="fas fa-plus text-success"></i>
                                        </div>
                                    </div>

                                    <?php if(!is_null($mr->address2)): ?>
                                        <div class="row pt-3" >
                                            <div class="col-sm-10">
                                                <input type="text" name="address2" class="form-control" value="<?php echo e($mr->address2); ?>" placeholder="<?php echo e($mr->address2); ?>">
                                            </div>
                                        </div>
                                        <?php endif; ?>

                                    <?php if(!is_null($mr->address3)): ?>
                                        <div class="row pt-3" >
                                            <div class="col-sm-10">
                                                <input type="text" name="address3" class="form-control" value="<?php echo e($mr->address3); ?>" placeholder="<?php echo e($mr->address3); ?>">
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-sm-6 col-md-6">
                                <div id="email" class="form-group">
                                    <label for="exampleInputEmail">Email</label>
                                    <div class="row">
                                        <div class="col-sm-10">
                                            <input type="text" name="email1" class="form-control" id="exampleInputEmail" value="<?php echo e($mr->email1); ?>" placeholder="<?php echo e($mr->email1); ?>">
                                        </div>
                                        <div  class="col-sm-1 align-self-center">
                                            <i class="fas fa-plus text-success" id="addition_email"></i>
                                        </div>
                                    </div>

                                    <?php if(!is_null($mr->email2)): ?>
                                        <div class="row pt-3">
                                            <div class="col-sm-10">
                                                <input type="text" name="email2" value="<?php echo e($mr->email2); ?>" class="form-control" placeholder="<?php echo e($mr->email2); ?>">
                                            </div>
                                        </div>
                                        <?php endif; ?>

                                    <?php if(!is_null($mr->email3)): ?>
                                        <div class="row pt-3">
                                            <div class="col-sm-10">
                                                <input type="text" name="email3" value="<?php echo e($mr->email3); ?>" class="form-control" placeholder="<?php echo e($mr->email3); ?>">
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-6 col-md-4">
                                <div id="contact" class="form-group">
                                    <label for="exampleInputContact">Contact</label>
                                    <div class="row">
                                        <div class="col-sm-10">
                                            <input type="text" name="contact1" class="form-control" id="exampleInputContact" value="<?php echo e($mr->contact1); ?>" placeholder="<?php echo e($mr->contact1); ?>">
                                        </div>
                                        <div class="col-sm-1 align-self-center text-center">
                                            <i id="addition_contact" class="fas fa-plus text-success"></i>
                                        </div>
                                    </div>

                                    <?php if(!is_null($mr->contact2)): ?>
                                        <div class="row pt-3">
                                            <div class="col-sm-10">
                                                <input type="text" name="contact2" value="<?php echo e($mr->contact2); ?>" class="form-control" placeholder="<?php echo e($mr->contact2); ?>">
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(!is_null($mr->contact3)): ?>
                                        <div class="row pt-3">
                                            <div class="col-sm-10">
                                                <input type="text" name="contact3" value="<?php echo e($mr->contact3); ?>" class="form-control" placeholder="<?php echo e($mr->contact3); ?>">
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-sm-6 col-md-4">
                                <div class="form-group">
                                    <label for="exampleInputFax">Fax</label>
                                    <div class="row">
                                        <div class="col-sm-10">
                                            <input type="text" name="fax" class="form-control" id="exampleInputFax" value="<?php echo e($mr->fax); ?>" placeholder="<?php echo e($mr->fax); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-6 col-md-4">
                                <div class="form-group">
                                    <label for="exampleInputFile">Choose Photo</label>
                                    <div class="input-group">
                                        <div class="input-group-append">
                                            <input type="file" name="image" class="custom-file-input" id="exampleInputFile">
                                            <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="row mt-5 text-center">
            <div class="col card-footer">
                <a href="/mr/<?php echo e($mr->id); ?>" class="btn btn-warning">View</a>
            </div>
            <div class="col card-footer">
                <a class="btn btn-success px-4"
                   onclick="event.preventDefault();
                                                     document.getElementById('mr-update').submit();">
                    Update
                </a>
            </div>
            <div class="col card-footer">
                <a class="btn btn-danger" href="<?php echo e(route('mr.destroy',['mr'=>$mr->id])); ?>"
                   onclick="event.preventDefault();
                                                     document.getElementById('mr-delete').submit();">
                    Delete
                </a>
                <form id="mr-delete" action="<?php echo e(route('mr.destroy',['mr'=>$mr->id])); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
            </div>
        </div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger mt-4" role="alert">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul>
                        <li><?php echo e($error); ?></li>
                    </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

    <script >
        $(document).ready(function(){

            let address_i = 1;
            let contact_i = 1;
            let email_i = 1;
            // add additional work and job field
            $("#addition_address").click(function () {
                address_i++
                if(address_i <=3){
                    $("#address").append(`<div class="row pt-3" >
                                        <div class="col-sm-10">
                                            <input type="text" name="address${address_i}" class="form-control" placeholder="Enter Another address">
                                        </div>
                                    </div>`);
                }
            });

            $("#addition_email").click(function () {
                email_i++
                if(email_i<=3){
                    $("#email").append(`<div class="row pt-3" >
                                        <div class="col-sm-10">
                                            <input type="text" name="email${email_i}" class="form-control" placeholder="Enter Another Email">
                                        </div>
                                    </div>`);
                }

            });

            $("#addition_contact").click(function () {
                contact_i++
                if(contact_i<=3){
                    $("#contact").append(`<div class="row pt-3" >
                                        <div class="col-sm-10">
                                            <input type="text" name="email${contact_i}" class="form-control" placeholder="Enter Another Contact">
                                        </div>
                                    </div>`);
                }

            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache\htdocs\Project\Boyshaki\MedicineShop\resources\views/pages/edit/showMREditForm.blade.php ENDPATH**/ ?>
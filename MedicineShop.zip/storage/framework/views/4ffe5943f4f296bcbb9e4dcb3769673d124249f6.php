<?php $__env->startSection('about-active','active'); ?>
<?php $__env->startSection('body'); ?>

    <div class="container about-header">
        <h1>About Us</h1>
        <hr class="about-uline">

        <div>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus, eos inventore ipsam libero nihil
                quasi sit! Amet aperiam commodi debitis deleniti dicta distinctio eaque eius fugit iste modi odit
                reiciendis repellendus reprehenderit, tempora totam. Architecto cum doloremque dolores ducimus eaque
                fugiat in incidunt, ipsa minima neque nisi odio odit quibusdam, ratione, sed soluta veritatis?
                Accusantium alias architecto corporis delectus doloremque illum nostrum odit placeat quae, reiciendis
                repellat rerum. Alias aliquam architecto asperiores atque doloribus ducimus eius eligendi eos fuga id
                laborum nesciunt obcaecati perferendis possimus quas quasi quos reiciendis sint tempore, tenetur unde
                ut veniam voluptates. A accusantium aliquid amet aperiam assumenda autem culpa cupiditate debitis
                doloremque dolores dolorum exercitationem explicabo, fuga illo incidunt ipsum iste laudantium maiores,
                minima molestias necessitatibus nemo nesciunt odio odit officia pariatur quae quaerat quasi qui rem
                saepe sit soluta suscipit tenetur ut veniam voluptas. Accusamus aperiam culpa dolore doloremque est
                hic nobis nostrum perspiciatis quisquam similique! Accusantium aliquam aperiam at beatae blanditiis,
                commodi, cumque debitis dolorem enim et labore laboriosam molestias quam quasi rerum sint velit
                voluptates. Ab, ad aliquam, blanditiis, corporis cumque cupiditate doloribus expedita harum in magnam
                necessitatibus possimus praesentium quaerat quos reprehenderit similique voluptate! Autem corporis ea
                eius, odit quidem rerum tempora? Blanditiis commodi dignissimos, dolorem enim eum ex ipsum modi nemo
                nulla placeat provident quaerat recusandae sapiente sit suscipit totam velit veniam? Aspernatur aut
                consectetur culpa cumque cupiditate debitis dolorum error facilis in ipsa ipsam laboriosam modi
                molestiae nam natus nostrum nulla officiis, omnis provident quae quis quos sapiente tempora tenetur
                veniam veritatis vero voluptas. Ad asperiores at blanditiis cumque distinctio esse illum provident rem
                repudiandae voluptatem. Alias aperiam commodi corporis delectus ducimus earum laborum maxime natus
                nemo, nulla, optio saepe similique voluptate. Aliquam asperiores doloribus officia possimus provident
                quisquam quo rerum? Assumenda, consectetur consequuntur delectus deleniti dolore dolorem earum, fugit
                illum ipsum laudantium maiores modi nemo odio, quos reiciendis sapiente sit totam vitae. Aliquid,
                aspernatur assumenda autem, culpa debitis deserunt dolor dolorum eius error, et expedita facere
                incidunt ipsam perspiciatis rerum sed voluptates? Assumenda deleniti distinctio eligendi facere fugiat
                illum iure laborum natus, nemo, nesciunt officiis optio quaerat recusandae.</p>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache\htdocs\Project\Boyshaki\MedicineShop\resources\views/pages/aboutUs.blade.php ENDPATH**/ ?>
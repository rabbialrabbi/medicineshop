<?php $__env->startSection('title','Item Edit'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="pt-3" style="text-align: center"><?php echo e($item->name); ?></h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content_body'); ?>
    <div class="container mr-element">
        <div class="row">
            <div class="col-sm-12 col-md-4 pt-5">
                <img class="mr-element_img" src="/storage/item/<?php echo e($item->image); ?>" alt="<?php echo e($item->name); ?>" height="300px" width="300px">
            </div>
            <div class="col-sm-12 col-md-8 pt-5">
                <form role="form" id="item-update" action="<?php echo e(route('item.update',['item'=>$item->id])); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-6 col-md-8">
                                <div class="form-group">
                                    <label for="exampleInputName">Item Name</label>
                                    <input type="text" name="name" class="form-control" value="<?php echo e($item->name); ?>" id="exampleInputName" placeholder="<?php echo e($item->name); ?>" required>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <div class="form-group">
                                    <label for="exampleInputCode">Item Code</label>
                                    <input type="text" name="code" class="form-control" value="<?php echo e($item->code); ?>" id="exampleInputCode" placeholder="<?php echo e($item->code); ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-6 col-md-3">
                                <div class="form-group">
                                    <label for="exampleInputDosage">Dosage</label>
                                    <input type="text" name="dosage" class="form-control" value="<?php echo e($item->dosage); ?>" id="exampleInputDosage" placeholder="<?php echo e($item->dosage); ?>" required>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-3">
                                <div class="form-group">
                                    <label for="exampleInputSize">Size</label>
                                    <input type="text" name="size" class="form-control" value="<?php echo e($item->size); ?>" id="exampleInputSize" placeholder="<?php echo e($item->size); ?>" required>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputPrice">Price</label>
                                    <input type="text" name="price" class="form-control" value="<?php echo e($item->price); ?>" id="exampleInputPrice" placeholder="<?php echo e($item->price); ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>Item Type</label>
                                    <select class="form-control" name="item_type_id" value="<?php echo e($item->itemType->id); ?>" required>
                                        <?php $__currentLoopData = $itemType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($i->id); ?>"><?php echo e($i->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>Generic Name</label>
                                    <select class="form-control" name="generic_id" value="<?php echo e($item->generic->id); ?>" required>
                                        <?php $__currentLoopData = $generic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($i->id); ?>"><?php echo e($i->name); ?></option >
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group ">
                                    <label>Brand Name</label>
                                    <select class="form-control" name="brand_id" value="<?php echo e($item->brand->id); ?>" required>
                                        <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($i->id); ?>"><?php echo e($i->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea class="form-control" rows="3" placeholder="<?php echo e($item->description); ?>" name="description" required><?php echo e($item->description); ?></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="exampleInputFile">Choose Photo</label>
                                    <div class="input-group">
                                        <div class="input-group-append">
                                            <input type="file" class="custom-file-input" id="exampleInputFile" name="image" required>
                                            <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="row mt-5 text-center">
            <div class="col card-footer">
                <a class="btn btn-warning px-4" href="<?php echo e(route('item.show',['item'=>$item->id])); ?>">
                    View
                </a>
            </div>
            <div class="col card-footer">
                <a class="btn btn-success px-4" onclick="event.preventDefault();document.getElementById('item-update').submit();">
                    Update
                </a>
            </div>
            <div class="col card-footer">
                <a class="btn btn-danger" href="<?php echo e(route('item.destroy',['item'=>$item->id])); ?>"
                   onclick="event.preventDefault();
                                                     document.getElementById('item-delete').submit();">
                    Delete
                </a>
                <form id="item-delete" action="<?php echo e(route('item.destroy',['item'=>$item->id])); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
            </div>
        </div>


        <?php if($errors->any()): ?>
            <div class="alert alert-danger mt-4" role="alert">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul>
                        <li><?php echo e($error); ?></li>
                    </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache\htdocs\Project\Boyshaki\MedicineShop\resources\views/pages/edit/showItemEditForm.blade.php ENDPATH**/ ?>
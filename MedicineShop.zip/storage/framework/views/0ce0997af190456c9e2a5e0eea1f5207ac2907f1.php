<?php echo e($slot); ?>

<?php /**PATH D:\Apache\htdocs\Project\Boyshaki\MedicineShop\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
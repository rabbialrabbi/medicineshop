<?php $__env->startSection('promo'); ?>
    <section>
        <div class="carousel">
            !! Promotional Add !!
        </div>
    </section>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache\htdocs\Project\Boyshaki\MedicineShop\resources\views/layouts/frontWithPromo.blade.php ENDPATH**/ ?>
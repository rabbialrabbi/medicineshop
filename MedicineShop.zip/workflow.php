<!-- Work Flow

    Design

 // Multi language Setup

 // Email Verification
 // Pdf Generator
 // Database Design for order place
 // Roll Type Auth
 // MR page Design (Add Card)
 // Relation with cascade
 // Multi auth Structure setup
 // Add Form design


 -->

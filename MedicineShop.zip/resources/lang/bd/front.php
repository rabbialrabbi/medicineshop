<?php


return [

    'home'=>'হোম',
    'about_us'=>'পরিচিতি',
    'product'=>'পণ্য',
    'mr_list'=>'এমআর তালিকা',
    'message'=>'বার্তা',
    'notice'=>'নোটিস',
    'contact'=>'যোগাযোগ',
    'log_out'=>'লগ আউট',
    'log_in'=>'লগ ইন',

];

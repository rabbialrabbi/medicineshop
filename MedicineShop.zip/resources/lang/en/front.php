<?php


return [

    'home'=>'Home',
    'about_us'=>'About Us',
    'product'=>'Product',
    'mr_list'=>'MR List',
    'message'=>'Message',
    'notice'=>'Notice',
    'contact'=>'Contact',
    'log_out'=>'Logout',
    'log_in'=>'LogIn',

];

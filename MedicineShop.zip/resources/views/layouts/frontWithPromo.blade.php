@extends('layouts.frontLayout')

@section('promo')
    <section>
        <div class="carousel">
            !! Promotional Add !!
        </div>
    </section>

    @endsection

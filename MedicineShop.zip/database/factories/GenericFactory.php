<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Generic;
use Faker\Generator as Faker;

$factory->define(Generic::class, function (Faker $faker) {
    return [
        //
    ];
});

<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\MR;
use Faker\Generator as Faker;

$factory->define(MR::class, function (Faker $faker) {
    return [
        //
    ];
});
